
package com.mycompany.templatmethod;

import java.io.*;
import modelo.*;


public class Main {

    public static void main(String[] args) {
        new Opcoes();
        //Conversor convert = new ToXls();
        //convert.exportar("C:\\Users\\Fernando Vasques\\Desktop\\dados.csv", "saida.xls");
        //convert = new ToPDF();
        //convert.exportar("C:\\Users\\Fernando Vasques\\Desktop\\dados.csv", "saida.pdf");
        //convert = new ToDoc();
        //convert.exportar("C:\\Users\\Fernando Vasques\\Desktop\\dados.csv", "saida.doc");
        /*File curDir = new File(".");
        for(int i = 0; i < curdir.listFiles().length; i++){
            System.out.println(curdir.listFiles()[i].getName());
        }*/
    }
    
}
