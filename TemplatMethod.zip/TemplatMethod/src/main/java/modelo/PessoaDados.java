
package modelo;

public class PessoaDados {
    private String[] dados;

    public String[] getDados() {
        return dados;
    }

    public void setDados(String[] dados) {
        this.dados = dados;
    }
    
    
}
